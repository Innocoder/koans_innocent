package com.sandwich.koan.suite;

import com.sandwich.koan.Koan;

public class OnePassingKoanDifferentName extends OnePassingKoan {

	@Koan
	public void koan() { }
	
}
