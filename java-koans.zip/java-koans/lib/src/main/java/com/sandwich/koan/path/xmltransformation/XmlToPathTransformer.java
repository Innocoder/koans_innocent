package com.sandwich.koan.path.xmltransformation;

import com.sandwich.koan.path.PathToEnlightenment.Path;

public interface XmlToPathTransformer {

	public Path transform();
	
}

